: ${BITS:="2048"}
: ${DAYS:="3650"}

: ${C:="US"}
: ${ST:="CA"}
: ${L:="San Francisco"}
: ${O:="Certified"}
